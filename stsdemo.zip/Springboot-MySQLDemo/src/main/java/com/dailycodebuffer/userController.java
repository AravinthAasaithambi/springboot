package com.dailycodebuffer;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController

public class userController {
	@Autowired
	private userRepository userRepository;
	@PostMapping("/user")
	public String createUser(@RequestParam("name") String name,@RequestParam("email") String email,@RequestParam("age") int age){
		user users=new user();
		users.setAge(age);
		users.setEmail(email);
		users.setName(name);
		userRepository.save(users);
		
		return "User Added Successfully";
		
	}
	@GetMapping("/user")
	public List<user> getAllUser(){
		List<user> aaaaa=userRepository.findAll();
		return userRepository.findAll();
	}
  @DeleteMapping("/user")
  public void deleteusers() {
	  userRepository.deleteAll();
	  
  }
}
